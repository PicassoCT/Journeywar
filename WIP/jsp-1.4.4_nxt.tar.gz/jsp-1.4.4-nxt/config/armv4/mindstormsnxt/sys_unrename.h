/* This file is generated from sys_rename.def by genrename. */

#ifdef _SYS_UNRENAME_H_
#undef _SYS_UNRENAME_H_

#ifndef OMIT_RENAME

#undef int_mask_table

#ifdef LABEL_ASM

#undef _int_mask_table

#endif /* LABEL_ASM */
#endif /* OMIT_RENAME */
#endif /* _SYS_UNRENAME_H_ */
