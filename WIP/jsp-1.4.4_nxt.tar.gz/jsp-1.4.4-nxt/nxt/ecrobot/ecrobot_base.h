#ifndef _ECROBOT_BASE_H_
#define _ECROBOT_BASE_H_

#ifndef _MACRO_ONLY
#include "rtos.h"

#define MAX_STATUS_BAR_LENGTH 16

extern S32 execution_mode(void);
extern void show_splash_screen(void);
extern void show_main_screen(void);
extern void display_status_bar(void);
extern void add_status_info(S32 status);
extern void check_NXT_buttons(VP_INT exinf);
extern void instruction_abort(unsigned long *preg);
extern void data_abort(unsigned long *preg);
extern void cpp_constructor(void);
extern void cpp_destructor(void);
#ifdef DEBUG
extern void show_bd_addr(U8 *bdaddr);
extern void show_bd_addr_err(void);
#endif	/* DEBUG */

#endif /* _MACRO_ONLY */
#endif
