/*****************************************************************************
 * FILE: ecrobot_base.c
 *
 * COPYRIGHT 2008 Takashi Chikamasa <takashic@cybernet.co.jp>
 *
 * <About leJOS NXJ>
 *  leJOS NXJ is a full firmware replacement of LEGO Mindstorms NXT and 
 *  designed for Java programming environment for the NXT 
 *  ( For more detailed information, please see: http://lejos.sourceforge.net/ )
 *  In the leJOS NXJ distribution, C source files for NXT platform layer is also
 *  included besides with the Java VM. The platform C source code is well
 *  structured, comprehensive, and achieved higher performance than the LEGO's
 *  one. Therefore, leJOS NXJ (platform) is also the best GCC based C/C++  
 *  development platform for NXT.
 *
 *  The contents of this file are subject to the Mozilla Public License
 *  Version 1.0 (the "License"); you may not use this file except in
 *  compliance with the License. You may obtain a copy of the License at
 *  http://www.mozilla.org/MPL/
 *
 *  Software distributed under the License is distributed on an "AS IS"
 *  basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
 *  License for the specific language governing rights and limitations
 *  under the License.
 *
 *  The Original Code is TinyVM code, first released March 6, 2000,
 *  later released as leJOS on September 23, 2000.
 *
 *  The Initial Developer of the Original Code is Jose H. Solorzano.
 *
 *  Contributor(s): see leJOS NXJ ACKNOWLEDGEMENTS .
 *
 *
 * <About TOPPERS OSEK>
 *  TOPPERS OSEK is an open source OSEK kernel and developed by TOPPERS project.
 *  TOPPERS(Toyohashi OPen Platform for Embedded Real-time Systems) has been managed 
 *  by a Non Profit Organization founded in Sep. 2003 and has been led by Professor
 *  Hiroaki Takada of Nagoya University in Japan. 
 *
 *  TOPPERS OSEK program is covered by the TOPPERS License as published
 *  by the TOPPERS PROJECT (http://www.toppers.jp/en/index.html).
 *
 *****************************************************************************/

#include "ecrobot_base.h"
#include "ecrobot_interface.h"
#include <string.h>

/* declarations for splash screen BMP file */
extern const UB nxtjsp_splash_bmp_start[];

/* used for getting the address of a constant data */
const U32 exec_addr[1] = {0};

/*
 * return where the program is executed
 */
S32 execution_mode(void)
{
	if (exec_addr < (volatile U32 *)0x200000)
	{
		return EXECUTED_FROM_FLASH;
	}
	return EXECUTED_FROM_SRAM;
}

/*
 * display application splash screen which is designed in
 * ecrobot_splash.bmp file
 */
void show_splash_screen(void)
{
	S32 row, column;
	S32 index;
	static U8 lcd[NXT_LCD_DEPTH*NXT_LCD_WIDTH];

	/* convert bmp file data to an array data for LCD */
	ecrobot_bmp2lcd(nxtjsp_splash_bmp_start, lcd, 100, 64);

	for (column = 0; column < NXT_LCD_WIDTH; column++)
	{
		for (row = 0; row < NXT_LCD_DEPTH; row++)
		{
			index = row * NXT_LCD_WIDTH + column;
			lcd[index] = ~lcd[index];
		}
		display_clear(0);
		display_bitmap_copy(lcd, 100, 8, 0, 0);
		display_refresh();
		sil_dly_nse((800/100)*1000000);
	}
	
	if (execution_mode() == EXECUTED_FROM_SRAM)
	{
		/* flip back to the original data for re-start */
		for (column = 0; column < NXT_LCD_WIDTH; column++)
		{
			for (row = 0; row < NXT_LCD_DEPTH; row++)
			{
				index = row * NXT_LCD_WIDTH + column;
				lcd[index] = ~lcd[index];
			}
		}
	}
	systick_wait_ms(200);
}

#ifndef TOPPERS_ATK1
/*
 *  undef instruction �������ץ����ȯ������ɽ���ѥϥ�ɥ�
 */
void instruction_abort(unsigned long *preg)
{
	display_clear(0);
	display_goto_xy(0, 0);
	display_string("Instruction abort");
	display_goto_xy(0, 1);
	display_string("PC   ");
	display_hex(preg[15], 8);
	display_goto_xy(0, 2);
	display_string("AASR ");
	display_hex(sil_rew_mem((VP)(TADR_MC_BASE+TOFF_MC_AASR)), 8);
	display_goto_xy(0, 3);
	display_string("ASR  ");
	display_hex(sil_rew_mem((VP)(TADR_MC_BASE+TOFF_MC_ASR)), 8);

	display_update();
	while(1);
}

/*
 *  data abort �������ץ����ȯ������ɽ���ѥϥ�ɥ�
 */
void data_abort(unsigned long *preg)
{
	display_clear(0);
	display_goto_xy(0, 0);
	display_string("Data abort");
	display_goto_xy(0, 1);
	display_string("PC   ");
	display_hex(preg[15], 8);
	display_goto_xy(0, 2);
	display_string("AASR ");
	display_hex(sil_rew_mem((VP)(TADR_MC_BASE+TOFF_MC_AASR)), 8);
	display_goto_xy(0, 3);
	display_string("ASR  ");
	display_hex(sil_rew_mem((VP)(TADR_MC_BASE+TOFF_MC_ASR)), 8);

	display_update();
	while(1);
}

#else	/* TOPPERS_ATK1 */
/*
 *  data abort �������ץ����ȯ������ɽ���ѥϥ�ɥ�
 */
void data_abort(unsigned long *preg)
{
	display_clear(0);
	display_goto_xy(0, 0);
	display_string("Data abort");
	display_goto_xy(0, 1);
	display_string("PC   ");
	display_hex(preg, 8);
	display_goto_xy(0, 2);
	display_string("AASR ");
	display_hex(sil_rew_mem((VP)(TADR_MC_BASE+TOFF_MC_AASR)), 8);
	display_goto_xy(0, 3);
	display_string("ASR  ");
	display_hex(sil_rew_mem((VP)(TADR_MC_BASE+TOFF_MC_ASR)), 8);

	display_update();
	while(1);
}

/* C++ constructor/destructor table */
extern void (*__ctor_begin[])(void);
extern void (*__ctor_end)(void);
extern void (*__dtor_begin[])(void);
extern void (*__dtor_end)(void);

/*
 * execute C++ constructors
 */
void cpp_constructor(void)
{
    int i;

    /* call all global object constructors */
    for (i=0;__ctor_begin[i] != __ctor_end;i++)
      (*__ctor_begin[i])();
}

/*
 * execute C++ destructors
 */
void cpp_destructor(void)
{
    int i;

    /* call all global object destructors */
    for (i=0;__dtor_begin[i] != __dtor_end;i++)
      (*__dtor_begin[i])();
}

#endif	/* TOPPERS_ATK1 */

#ifdef DEBUG
void show_bd_addr(U8 *bd_addr)
{
	S32 i;

	display_clear(0);
	display_goto_xy(0, 0);
	display_string("BD_ADDR:");
	display_goto_xy(0, 1);
	for (i = 0; i < 7; i++)
	{
		display_hex(bd_addr[i], 2);
	}
	display_refresh();
	systick_wait_ms(200);
}

void show_bd_addr_err(void)
{
	display_goto_xy(0, 0);
	display_string("BD_ADDR: FAILED");
	display_goto_xy(0, 1);
	display_string("RESTART NXT.");
	display_refresh();
	systick_wait_ms(5000);
}
#endif	/* DEBUG */

