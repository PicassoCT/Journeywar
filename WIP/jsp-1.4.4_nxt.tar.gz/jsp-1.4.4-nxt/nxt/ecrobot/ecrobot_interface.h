#ifndef _ECROBOT_INTERFACE_H_
#define _ECROBOT_INTERFACE_H_

/* LEJOS NXJ I/O drivers */
#include "mytypes.h"
#include "nxt_avr.h"
#include "twi.h"
#include "nxt_lcd.h"
#include "nxt_motors.h"
#include "sensors.h"
#include "display.h"
#include "i2c.h"
#include "bt.h"
#include "sound.h"
#include "udp.h"

#include "ecrobot_private.h"
#include "ecrobot_usb.h"

typedef struct {
  U32 battery_state;
   U8 buttons_state;
} nxt_inputs;

typedef struct {
  S8 speed;
  U8 mode;
} nxt_outputs;

#define BTN1 0x01
#define BTN2 0x02
#define BTN3 0x04
#define BTN4 0x08
#define ENTER_PRESSED BTN1
#define STOP_PRESSED  BTN2
#define RUN_PRESSED   BTN3
#define EXIT_PRESSED  BTN4

typedef enum {
	NXT_PORT_A,
	NXT_PORT_B,
	NXT_PORT_C
}MOTOR_PORT_T;

typedef enum {
	NXT_PORT_S1,
	NXT_PORT_S2,
	NXT_PORT_S3,
	NXT_PORT_S4
}SENSOR_PORT_T;

typedef enum {
	EXECUTED_FROM_FLASH,
	EXECUTED_FROM_SRAM,
	DEVICE_NO_INIT,
	DEVICE_INITIALIZED,
	BT_NO_INIT,
	BT_INITIALIZED,
	BT_CONNECTED,
	BT_STREAM,
}SYSTEM_T;

#define EXTERNAL_WAV_DATA(name) \
  extern const S8 name##_wav_start[]; \
  extern const S8 name##_wav_end[]; \
  extern const S8 name##_wav_size[]

#define WAV_DATA_START(name) name##_wav_start
#define WAV_DATA_END(name)   name##_wav_end
#define WAV_DATA_SIZE(name)  name##_wav_size

#define EXTERNAL_BMP_DATA(name) \
  extern const S8 name##_bmp_start[]; \
  extern const S8 name##_bmp_end[]; \
  extern const S8 name##_bmp_size[]

#define BMP_DATA_START(name) name##_bmp_start
#define BMP_DATA_END(name)   name##_bmp_end
#define BMP_DATA_SIZE(name)  name##_bmp_size

#define LOWSPEED_9V 1
#define LOWSPEED    2


/*==============================================================================
 * NXT Servo Motor API
 *=============================================================================*/

/**
 * set Servo Motor PWM duty ratio
 *
 * @param port_id: NXT_PORT_A/NXT_PORT_B/NXT_PORT_C
 * @param speed: PWM duty ration (-100 to 100)
 */
#define ecrobot_set_motor_speed(port_id, speed)    nxt_motor_set_speed(port_id, speed, 1)
	/* 1st arg:port id (0/1/2)        */
	/* 2nd arg:speed (-100 to 100)    */
	/* 3rd arg:mode (1:brake/0:float) */

	/* As far as we tested the controllability of motor position for 
	 * precise real-time control applications (e.g. NXTway-GS, NXT GT)
	 * brake mode seems to be better.
	 */

/**
 * set Servo Motor brake mode and PWM duty ratio
 *
 * @param port_id: NXT_PORT_A/NXT_PORT_B/NXT_PORT_C
 * @param mode: 0(float)/1(brake)
 * @param speed: PWM duty ratio (-100 to 100)
 */
#define ecrobot_set_motor_mode_speed(port_id, mode, speed) nxt_motor_set_speed(port_id, speed, mode)
	/* 1st arg:port id (0/1/2)        */
	/* 2nd arg:speed (-100 to 100)    */
	/* 3rd arg:mode (1:brake/0:float) */

/**
 * get Servo Motor revolution in degree
 *
 * @param port_id: NXT_PORT_A/NXT_PORT_B/NXT_PORT_C
 * @return: motor revolution in degree
 */
#define ecrobot_get_motor_rev(port_id)             nxt_motor_get_count(port_id)

/**
 * set Servo Motor revolution in degree
 *
 * @param port_id: NXT_PORT_A/NXT_PORT_B/NXT_PORT_C
 * @param rev: motor revolution in degree
 */
#define ecrobot_set_motor_rev(port_id, rev)        nxt_motor_set_count(port_id, rev)


/*==============================================================================
 * NXT A/D Sensors API
 *=============================================================================*/

/**
 * initial Sensors
 *
 */
#define ecrobot_init_sensors                       init_sensors

/**
 * turn infra-red light on
 *
 * @param port_id: NXT_PORT_S1/NXT_PORT_S2/NXT_PORT_S3/NXT_PORT_S4
 */
#define ecrobot_set_light_sensor_active(port_id)   set_digi0(port_id)

/**
 * turn infra-red light off
 *
 * @param port_id: NXT_PORT_S1/NXT_PORT_S2/NXT_PORT_S3/NXT_PORT_S4
 */
#define ecrobot_set_light_sensor_inactive(port_id) unset_digi0(port_id)

/**
 * get Light Sensor raw A/D data
 *
 * @param port_id: NXT_PORT_S1/NXT_PORT_S2/NXT_PORT_S3/NXT_PORT_S4
 * @return: A/D raw data(0 to 1023)
 */
#define ecrobot_get_light_sensor(port_id)          sensor_adc(port_id)

/**
 * get Touch Sensor on/off status
 *
 * @param port_id: NXT_PORT_S1/NXT_PORT_S2/NXT_PORT_S3/NXT_PORT_S4
 * @return: 1(touched)/0(not touched)
 */
#define ecrobot_get_touch_sensor(port_id)          (sensor_adc(port_id) < 512)

/**
 * get Sound Sensor raw A/D data
 *
 * @param port_id: NXT_PORT_S1/NXT_PORT_S2/NXT_PORT_S3/NXT_PORT_S4
 * @return: A/D raw data(0 to 1023)
 */
#define ecrobot_get_sound_sensor(port_id)          (U16)(sensor_adc(port_id))


/* private common functions */
extern   U8 ecrobot_get_button_state(void);
extern void ecrobot_init_nxtstate(void);
extern void ecrobot_poll_nxtstate(void);

/* NXT Timer API */
extern U32 ecrobot_systick_get_ms(void);

/* NXT I2C API */
extern void ecrobot_init_i2c(U8 port_id, U8 type);
extern   U8 ecrobot_wait_i2c_ready(U8 port_id, U32 wait);
extern  S32 ecrobot_send_i2c(U8 port_id, U32 address, S32 i2c_reg, U8 *buf, U32 len);
extern  S32 ecrobot_read_i2c(U8 port_id, U32 address, S32 i2c_reg, U8 *buf, U32 len);

/**
 * terminate a NXT sensor port used for I2C communication
 *
 * @param port_id: NXT_PORT_S1/NXT_PORT_S2/NXT_PORT_S3/NXT_PORT_S4
 */
#define ecrobot_term_i2c(port_id)                  i2c_disable(port_id)

/* NXT ultrasonic sensor API */
/**
 * init a NXT sensor port for Ultrasonic Sensor
 *
 * @param port_id: NXT_PORT_S1/NXT_PORT_S2/NXT_PORT_S3/NXT_PORT_S4
 */
#define ecrobot_init_sonar_sensor(port_id)         ecrobot_init_i2c(port_id, LOWSPEED)

extern  S32 ecrobot_get_sonar_sensor(U8 port_id);
extern void ecrobot_term_sonar_sensor(U8 port_id);

/* HiTechnic gyro sensor API */
/**
 * get HiTechnic Gyro Sensor raw A/D data
 *
 * @param port_id: NXT_PORT_S1/NXT_PORT_S2/NXT_PORT_S3/NXT_PORT_S4
 * @return: A/D raw data(0 to 1023)
 */
#define ecrobot_get_gyro_sensor(port_id)           sensor_adc(port_id)

/* HiTechnic acceleration sensor API */
/**
 * init a NXT port for I2C device(Acceleration Sensor)
 *
 * @param port_id: NXT_PORT_S1/NXT_PORT_S2/NXT_PORT_S3/NXT_PORT_S4
 */
#define ecrobot_init_accel_sensor(port_id)         ecrobot_init_i2c(port_id, LOWSPEED)

extern void ecrobot_get_accel_sensor(U8 port_id, S16 buf[3]);
/**
 * terminate a NXT port for I2C device(Acceleration Sensor)
 *
 * @param port_id: NXT_PORT_S1/NXT_PORT_S2/NXT_PORT_S3/NXT_PORT_S4
 */
#define ecrobot_term_accel_sensor(port_id)         i2c_disable(port_id)

/* HiTechnic IR Seeker API */
/**
 * init a NXT port for I2C device(IR Seeker)
 *
 * @param port_id: NXT_PORT_S1/NXT_PORT_S2/NXT_PORT_S3/NXT_PORT_S4
 */
#define ecrobot_init_ir_seeker(port_id)            ecrobot_init_i2c(port_id, LOWSPEED)

extern void ecrobot_get_ir_seeker(U8 port_id, S8 buf[6]);

/**
 * terminate a NXT port for I2C device(IR Seeker)
 *
 * @param port_id: NXT_PORT_S1/NXT_PORT_S2/NXT_PORT_S3/NXT_PORT_S4
 */
#define ecrobot_term_ir_seeker(port_id)            i2c_disable(port_id)

/* HiTechnic color sensor API */
/**
 * init a NXT port for I2C device(Color Sensor)
 *
 * @param port_id: NXT_PORT_S1/NXT_PORT_S2/NXT_PORT_S3/NXT_PORT_S4
 */
#define ecrobot_init_color_sensor(port_id)         ecrobot_init_i2c(port_id, LOWSPEED)

extern void ecrobot_get_color_sensor(U8 port_id, S16 buf[3]);

/**
 * terminate a NXT port for I2C device(Color Sensor)
 *
 * @param port_id: NXT_PORT_S1/NXT_PORT_S2/NXT_PORT_S3/NXT_PORT_S4
 */
#define ecrobot_term_color_sensor(port_id)         i2c_disable(port_id)

/* HiTechnic compass sensor API */
/**
 * init a NXT port for I2C device(Compass Sensor)
 *
 * @param port_id: NXT_PORT_S1/NXT_PORT_S2/NXT_PORT_S3/NXT_PORT_S4
 */
#define ecrobot_init_compass_sensor(port_id)       ecrobot_init_i2c(port_id, LOWSPEED)

extern   U8 ecrobot_cal_compass_sensor(U8 port_id);
extern  S16 ecrobot_get_compass_sensor(U8 port_id);

/**
 * terminate a NXT port for I2C device(Compass Sensor)
 *
 * @param port_id: NXT_PORT_S1/NXT_PORT_S2/NXT_PORT_S3/NXT_PORT_S4
 */
#define ecrobot_term_compass_sensor(port_id)       i2c_disable(port_id)

/*==============================================================================
 * RCX Sensors API
 * 
 * According to LEGO Hardware Developer Kit, RCX sensors are categorized as
 * two types
 *   ACTIVE SENSOR:  RCX Light Sensor, RCX Rotation Sensor
 *   PASSIVE SENSOR: RCX Touch Sensor
 * ACTIVE SENSOR requires additional power source to drive the sensor
 * PASSIVE SENSOR is compatible with NXT A/D sensors
 *
 * Concept of these RCX Sensors API is contributed by Maurits Kooiman(Mansk).
 * see http://forums.nxtasy.org/index.php?showtopic=1540
 *=============================================================================*/
/**
 * supply power source for ACTIVE SENSORS
 *
 * @param port_id: NXT_PORT_S1/NXT_PORT_S2/NXT_PORT_S3/NXT_PORT_S4
 */
#define ecrobot_set_RCX_power_source(port_id)      nxt_avr_set_input_power(port_id, LOWSPEED_9V)
/**
 * stop power source for ACTIVE SENSORS
 *
 * @param port_id: NXT_PORT_S1/NXT_PORT_S2/NXT_PORT_S3/NXT_PORT_S4
 */
#define ecrobot_term_RCX_power_source(port_id)     nxt_avr_set_input_power(port_id, 0)
/**
 * get RCX Sensor raw A/D data
 *
 * @param port_id: NXT_PORT_S1/NXT_PORT_S2/NXT_PORT_S3/NXT_PORT_S4
 * @return: raw A/D data (0 to 1023)
 */
#define ecrobot_get_RCX_sensor(port_id)            sensor_adc(port_id)
/**
 * get RCX Touch Sensor on/off status
 *
 * @param port_id: NXT_PORT_S1/NXT_PORT_S2/NXT_PORT_S3/NXT_PORT_S4
 * @return: 1(touched)/0(not touched)
 */
#define ecrobot_get_RCX_touch_sensor(port_id)      (sensor_adc(port_id) < 512)

/* NXT internal status API */
extern  U16 ecrobot_get_battery_voltage(void);
#define ecrobot_get_systick_ms                     ecrobot_systick_get_ms

/**
 * get ENTER buttons status 
 *  NOTE that STOP and EXIT buttons are preserved by the system,
 *  so should not be disclosed to application.
 *
 * @return: 1(pressed)/0(not pressed)
 */
#define ecrobot_is_ENTER_button_pressed()          ((ecrobot_get_button_state() & ENTER_PRESSED) == ENTER_PRESSED)

/**
 * get RUN buttons status 
 *  NOTE that STOP and EXIT buttons are preserved by the system,
 *  so should not be disclosed to application.
 *
 * @return: 1(pressed)/0(not pressed)
 */
#define ecrobot_is_RUN_button_pressed()            ((ecrobot_get_button_state() & RUN_PRESSED) == RUN_PRESSED)

/* LCD display command for system */
extern  S32 ecrobot_bmp2lcd(const S8 *file, U8 *lcd, S32 width, S32 height);
extern void ecrobot_status_monitor(const S8 *target_name);
#ifdef DEBUG
extern void ecrobot_show_int(S32 var);
extern void ecrobot_debug1(U32 var1, U32 var2, U32 var3);
extern void ecrobot_debug2(U32 var1, U32 var2, U32 var3);
extern void ecrobot_bt_data_logger(S8 data1, S8 data2);
extern void ecrobot_bt_adc_data_logger(S8 data1, S8 data2, S16 adc1, S16 adc2, S16 adc3, S16 adc4);
#endif	/* DEBUG */

/* NXT sound API */
extern  S32 ecrobot_sound_tone(U32 freq, U32 ms, U32 vol);
extern  S32 ecrobot_sound_wav(const S8 *file, U32 length, S32 freq, U32 vol);

#endif
