/*****************************************************************************
 * FILE: ecrobot_interface.c
 *
 * COPYRIGHT 2008 Takashi Chikamasa <takashic@cybernet.co.jp>
 *
 * <About leJOS NXJ>
 *  leJOS NXJ is a full firmware replacement of LEGO Mindstorms NXT and 
 *  designed for Java programming environment for the NXT 
 *  ( For more detailed information, please see: http://lejos.sourceforge.net/ )
 *  In the leJOS NXJ distribution, C source files for NXT platform layer is also
 *  included besides with the Java VM. The platform C source code is well
 *  structured, comprehensive, and achieved higher performance than the LEGO's
 *  one. Therefore, leJOS NXJ (platform) is also the best GCC based C/C++  
 *  development platform for NXT.
 *
 *  The contents of this file are subject to the Mozilla Public License
 *  Version 1.0 (the "License"); you may not use this file except in
 *  compliance with the License. You may obtain a copy of the License at
 *  http://www.mozilla.org/MPL/
 *
 *  Software distributed under the License is distributed on an "AS IS"
 *  basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
 *  License for the specific language governing rights and limitations
 *  under the License.
 *
 *  The Original Code is TinyVM code, first released March 6, 2000,
 *  later released as leJOS on September 23, 2000.
 *
 *  The Initial Developer of the Original Code is Jose H. Solorzano.
 *
 *  Contributor(s): see leJOS NXJ ACKNOWLEDGEMENTS .
 *
 *
 * <About TOPPERS OSEK>
 *  TOPPERS OSEK is an open source OSEK kernel and developed by TOPPERS project.
 *  TOPPERS(Toyohashi OPen Platform for Embedded Real-time Systems) has been managed 
 *  by a Non Profit Organization founded in Sep. 2003 and has been led by Professor
 *  Hiroaki Takada of Nagoya University in Japan. 
 *
 *  TOPPERS OSEK program is covered by the TOPPERS License as published
 *  by the TOPPERS PROJECT (http://www.toppers.jp/en/index.html).
 *
 *****************************************************************************/

#include <rtos.h>
#include <stddef.h>
#include <string.h>

#include "ecrobot_interface.h"

#define ecrobot_get_bt_status()  bluetooth_get_connect_state(CONSOLE_PORTID)

/*==============================================================================
 * NXT Timer API
 *=============================================================================*/
/**
 * get System tick in mille second
 *
 * @return: time in msec.
 *  NOTE that system tick is started when the NXT was turned on.
 *  not when application was started.
 */
U32 ecrobot_systick_get_ms(void)
{
	SYSTIM time;
	get_tim(&time);
  // We're using a 32-bitter and can assume that we
  // don't need to do any locking here.
  return time;
}

/*==============================================================================
 * NXT Ultrasonic Sensor API
 *=============================================================================*/
S32 distance_state[4] = {-1,-1,-1,-1}; /* -1: sensor is not connected */

static S32 getDistance(void)
{
	S32 i;
	
	/*
 	 * if multiple Ultrasonic Sensors are connected to a NXT,
 	 * only the senosr measurement data which is connected to the smallest port id
 	 * can be monitored in LCD and logging data.
 	 */
	for (i = 0; i < 4; i++)
	{
		if (distance_state[i] != -1)
		{
			return distance_state[i];
		}
	}
	return -1;
}

/*==============================================================================
 * NXT internal status API
 *=============================================================================*/
#define N_BTN_STATE 20

static nxt_inputs ecrobot_inputs;
static U8 buttons_states[N_BTN_STATE];
static S32 buttons_i;

/**
 * get battery voltage in mille volt
 *
 * @return: battery voltage in mV (e.g. 9000 = 9.000V)
 */
U16 ecrobot_get_battery_voltage(void)
{
	return (U16)ecrobot_inputs.battery_state;
}

void ecrobot_init_nxtstate(void)
{
//	ecrobot_inputs.battery_state = 0;
	ecrobot_inputs.buttons_state = 0;
	memset(buttons_states, 0, sizeof(buttons_states));
	buttons_i = 0;
}

U8 ecrobot_get_button_state(void)
{
	return ecrobot_inputs.buttons_state;
}

void ecrobot_poll_nxtstate(void)
{
	S32 i;

	ecrobot_inputs.battery_state = battery_voltage();

	/* button debouncer */
	buttons_states[buttons_i++] = (U8)buttons_get() & 0x0F;
	if (buttons_i == N_BTN_STATE) buttons_i = 0;
	for (i = 1; i < N_BTN_STATE; i++)
	{
		if (buttons_states[i-1] != buttons_states[i])
		{
	  		return;
		}
		
		if (i == N_BTN_STATE-1)
    	{
	  		ecrobot_inputs.buttons_state = buttons_states[i];
    	}
  	}
}

#ifdef DEBUG
/*==============================================================================
 * NXT Data Logging API for NXT GamePad
 *=============================================================================*/
static S16 adc[4]; /* used for ecrobot_adc_data_monitor */

/**
 * data logging API used with NXT GamePad
 *
 * @param data1: user configurable data to be logged
 * @param data2: user configurable data to be logged
 */
void ecrobot_bt_data_logger(S8 data1, S8 data2)
{
	U8 data_log_buffer[32];

	*((U32 *)(&data_log_buffer[0]))  = (U32)ecrobot_systick_get_ms();
	*(( S8 *)(&data_log_buffer[4]))  =  (S8)data1;
	*(( S8 *)(&data_log_buffer[5]))  =  (S8)data2;
	*((U16 *)(&data_log_buffer[6]))  = (U16)ecrobot_inputs.battery_state;
	*((S32 *)(&data_log_buffer[8]))  = (S32)nxt_motor_get_count(0);
	*((S32 *)(&data_log_buffer[12])) = (S32)nxt_motor_get_count(1);
	*((S32 *)(&data_log_buffer[16])) = (S32)nxt_motor_get_count(2);
	*((S16 *)(&data_log_buffer[20])) = (S16)sensor_adc(0);
	*((S16 *)(&data_log_buffer[22])) = (S16)sensor_adc(1);
	*((S16 *)(&data_log_buffer[24])) = (S16)sensor_adc(2);
	*((S16 *)(&data_log_buffer[26])) = (S16)sensor_adc(3);
	*((S32 *)(&data_log_buffer[28])) = (S32)getDistance();
	
	ecrobot_send_bt_packet(data_log_buffer, 32);
}

/**
 * data logging API used with NXT GamePad
 *
 * @param data1: user configurable data to be logged
 * @param data2: user configurable data to be logged
 * @param adc1:  user configurable data to be logged
 * @param adc2:  user configurable data to be logged
 * @param adc3:  user configurable data to be logged
 * @param adc4:  user configurable data to be logged
 */
void ecrobot_bt_adc_data_logger(S8 data1, S8 data2, S16 adc1, S16 adc2, S16 adc3, S16 adc4)
{
	U8 data_log_buffer[32];

	*((U32 *)(&data_log_buffer[0]))  = (U32)ecrobot_systick_get_ms();
	*(( S8 *)(&data_log_buffer[4]))  =  (S8)data1;
	*(( S8 *)(&data_log_buffer[5]))  =  (S8)data2;
	*((U16 *)(&data_log_buffer[6]))  = (U16)ecrobot_inputs.battery_state;
	*((S32 *)(&data_log_buffer[8]))  = (S32)nxt_motor_get_count(0);
	*((S32 *)(&data_log_buffer[12])) = (S32)nxt_motor_get_count(1);
	*((S32 *)(&data_log_buffer[16])) = (S32)nxt_motor_get_count(2);
	*((S16 *)(&data_log_buffer[20])) = (S16)adc1;
	*((S16 *)(&data_log_buffer[22])) = (S16)adc2;
	*((S16 *)(&data_log_buffer[24])) = (S16)adc3;
	*((S16 *)(&data_log_buffer[26])) = (S16)adc4;
	*((S32 *)(&data_log_buffer[28])) = (S32)getDistance();
	adc[0] = adc1;
	adc[1] = adc2;
	adc[2] = adc3;
	adc[3] = adc4;
	
	ecrobot_send_bt_packet(data_log_buffer, 32);
}
#endif	/* DEBUG */

/*==============================================================================
 * NXT LCD display API
 *=============================================================================*/

/**
 * convert a BMP file to an array data for LCD display
 *
 * @param file: monochrome BMP file data
 * @param lcd: data array to be drawn in LCD
 * @param width: pixel width of the BMP file (max. 100)
 * @param height: pixel height of the BMP file (max. 64)
 * @return: 1(success)/-1(failure)
 */
S32 ecrobot_bmp2lcd(const S8 *file, U8 *lcd, S32 width, S32 height)
{
	S32 bmp_line, bmp_line_alignment;
	S32 bmp_row, bmp_col;
	S32 lcd_row;
	S32 lcd_pos;
	S32 bmp_bit_pos;
	S32 lcd_bit_pos;
	S32 bits;
	U8 bmp_data;
	BMP *bmp = (BMP *)file;
	
	/* check a BMP file header information */
	if (bmp->fileHeader.type != BM_TYPE)  /* Windows */
		return -1;
	if ((bmp->infoHeader.width > NXT_LCD_WIDTH) ||
		(bmp->infoHeader.width < 1) ||
		(bmp->infoHeader.width != width))
		return -1;
	if ((bmp->infoHeader.height > NXT_LCD_DEPTH * 8) ||
		(bmp->infoHeader.height < 1) ||
		(bmp->infoHeader.height != height))
		return -1;
	if (bmp->infoHeader.bits != 1)        /* monochrome bmp */
		return -1;
	if (bmp->infoHeader.compression != 0) /* no compression */
		return -1;
	
	/* 
	 * Specifications of a monochrome bmp file
	 *
	 * - each bit represents a pixel.
	 * - each line has 4 bytes alignment.
	 *   (100 pixels data is saved in 100/8 = 12 + 1 + 3 = 16 byte)
	 * - data order in a BMP file:
     *   (0,n)---------------->(m,n)
     *        ---------------->
     *        ---------------->
     *        ---------------->
     *   (0,0)---------------->(m,0)
	 */
	 
	/* calculate line alignment */
	bmp_line = bmp->infoHeader.width / 8;
	if (bmp->infoHeader.width % 8)
	{
		bmp_line++;
	}
	
	if ((bmp_line % 4) != 0)
	{
		bmp_line_alignment = ((bmp_line / 4) + 1) * 4;
	}
	else
	{
		bmp_line_alignment = bmp_line;
	}
	
	/* convert BMP data to LCD array data */
	for (bmp_row = 0; bmp_row < bmp->infoHeader.height; bmp_row++)
	{
		lcd_row = NXT_LCD_DEPTH - ((bmp_row / 8) + 1);
		lcd_bit_pos = bmp_row % 8;
		bits = 0;
		for(bmp_col = 0; bmp_col < bmp_line; bmp_col++)
		{
			bmp_data = file[(bmp_row * bmp_line_alignment) + bmp_col + bmp->fileHeader.offset];
			lcd_pos = (lcd_row * NXT_LCD_WIDTH) + (bmp_col * 8);
			for (bmp_bit_pos = 0; ((bmp_bit_pos < 8) && (bits < bmp->infoHeader.width)); bmp_bit_pos++, bits++)
			{
				int lcd_index = lcd_pos + bmp_bit_pos;
				/* checks render data can be stored into LCD */
				if (lcd_index < NXT_LCD_WIDTH*NXT_LCD_DEPTH)
				{
					if (!(bmp_data & (0x01 << (7 - bmp_bit_pos))))
					{
						lcd[lcd_index] |= (0x80 >> lcd_bit_pos);
					}
					else
					{
						lcd[lcd_index] &= (~0x80 >> lcd_bit_pos);
					}
				}
			}
		}
	}
	return 1;
}

void ecrobot_status_monitor(const S8 *target_name)
{
	display_clear(0);

	display_goto_xy(0, 0);
   	display_string(target_name);

   	display_goto_xy(0, 1);
   	display_string("TIME:");
   	display_unsigned(ecrobot_systick_get_ms()/1000, 0);

   	display_goto_xy(0, 2);
   	display_string("BATT:");
   	display_unsigned(ecrobot_inputs.battery_state/100, 0);
    
   	display_goto_xy(0, 3);
   	display_string("REV: ");
   	display_int(nxt_motor_get_count(0), 0);
   	display_int(nxt_motor_get_count(1), 6);

   	display_goto_xy(0, 4);
   	display_string("     ");
   	display_int(nxt_motor_get_count(2), 0);

   	display_goto_xy(0, 5);
   	display_string("ADC: ");
   	display_unsigned(sensor_adc(0), 0);
   	display_unsigned(sensor_adc(1), 5);

   	display_goto_xy(0, 6);
   	display_string("     ");
   	display_unsigned(sensor_adc(2), 0);
   	display_unsigned(sensor_adc(3), 5);

   	display_goto_xy(0, 7);
   	display_string("BT/DST: ");
	if (ecrobot_get_bt_status() == BT_STREAM)
	{
		display_unsigned(1, 0);
   	}
   	else
   	{
		display_unsigned(0, 0);
   	}
   	display_int(getDistance(), 5);

	display_refresh();
}

#ifdef DEBUG
void ecrobot_show_int(S32 var)
{
	display_clear(0);

	display_goto_xy(0, 7);
	display_string("VAR: ");
	display_int(var, 0);

	display_refresh();
}

void ecrobot_debug(U32 var)
{
	display_clear(0);

	display_goto_xy(0, 7);
	display_string("DBG: ");
	display_int(var, 0);

	display_refresh();
}

void ecrobot_debug1(U32 var1, U32 var2, U32 var3)
{
	display_clear(0);

	display_goto_xy(0, 1);
	display_string("VAR1: ");
	display_int(var1, 0);

	display_goto_xy(0, 2);
	display_string("VAR2: ");
	display_int(var2, 0);

	display_goto_xy(0, 3);
	display_string("VAR3: ");
	display_int(var3, 0);

	display_refresh();
}

void ecrobot_debug2(U32 var1, U32 var2, U32 var3)
{
	display_clear(0);

	display_goto_xy(0, 4);
	display_string("VAR4: ");
	display_int(var1, 0);

	display_goto_xy(0, 5);
	display_string("VAR5: ");
	display_int(var2, 0);

	display_goto_xy(0, 6);
	display_string("VAR6: ");
	display_int(var3, 0);

	display_refresh();
}
#endif	/* DEBUG */

/*==============================================================================
 * NXT Sound API
 *=============================================================================*/

/**
 * play a tone(wrapper of leJOS sound tone api)
 *
 * @param freq: soundfrequency in Hz (31 to 2100)
 * @param ms: sound duration in centisecond (10 - 256)
 * @vol: sound volume (0 to 100)
 * @return 1 (always)
 */
S32 ecrobot_sound_tone(U32 freq, U32 ms, U32 vol)
{
#if 0	/* NOT SUPPORT */
	sound_freq_vol(freq, ms, vol);
#else	/* NOT SUPPORT */
	sound_freq(freq, ms);
#endif	/* NOT SUPPORT */
	return 1;
}

/**
 * play a WAV file (support for only 8bit monoral PCM)
 *
 * @param file: WAV file data
 *  NOTE that supports only 8bit monoral PCM
 * @param length: length of WAV file
 * @param freq: sampling frequency -1(inherit the WAV file original)/2000 to 22050Hz
 * @param vol: sound volume(0 to 100)
 * @return: 1(success)/0(sound resource is busy)/-1(failure)
 */
S32 ecrobot_sound_wav(const S8 *file, U32 length, S32 freq, U32 vol)
{
#if 0	/* NOT SUPPORT */
	WAV *wav = (WAV *)file;

	/* check sound resource is free */
	if (sound_get_time() > 0)
		return 0;
		
	/* check length of a file */
	if (length < WAV_HDR_SIZE)
		return -1;
	
	/* check a WAV file header information */
	if (wav->riff.chunkID != RIFF_CHUNK_ID)
		return -1;
	if (wav->riff.format != RIFF_FORMAT)
		return -1;
	if (wav->fmt.chunkID != FMT_CHUNK_ID)
		return -1;
	if (wav->fmt.audioFormat != 0x0001) /* PCM */
		return -1;
	if (wav->fmt.numChannels != 0x0001) /* mono channel */
		return -1;
	if (wav->fmt.bitsPerSample != 0x0008) /* 8bit */
		return -1;

	/* in case of freq < 0, freq(sample rate) is inherited from a WAV file */
	if (freq < 0)
	{
		freq = wav->fmt.sampleRate;
	}
	
	/* read wav data. Currently, supported PCM file types are 
	 * linear PCM(data chunkID is "data" and "fact") and non-linear PCM.
	 */
	if (wav->data.chunkID == DATA_CHUNK_ID)
	{
		/* linear PCM */
		sound_play_sample(wav->data.data, wav->data.chunkSize, (U32)freq, vol);
	}
	else
	{
		WAV_FACT *wav_fact = (WAV_FACT *)file;
		if (wav_fact->data.chunkID == FACT_CHUNK_ID && wav_fact->data.data_chunkID == DATA_CHUNK_ID)
		{
 			/* linear PCM with "fact" chunk ID */
			sound_play_sample(wav_fact->data.data, wav_fact->data.data_chunkSize, (U32)freq, vol);
		}
		else
		{
			WAV_NL *wav_nl = (WAV_NL *)file;
			if (wav_nl->data.chunkID == DATA_CHUNK_ID)
			{
 				/* non linear PCM */
				sound_play_sample(wav_nl->data.data, wav_nl->data.chunkSize, (U32)freq, vol);
			}
			else
			{
				return -1;
			}
		}
	}
	return 1;
#else	/* NOT SUPPORT */
	return -1;
#endif	/* NOT SUPPORT */
}

