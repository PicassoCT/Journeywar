
#include <osek_kernel.h>
#include "rtos.h"
#include "alarm.h"

/*
 *  OIL�������ܥ�γ�������
 */
DeclareCounter( SysTimerCnt );
DeclareEvent( MainEvt );

void (*rtos_1kHz_time_func[NUM_NXT_TIMER])(void);

void
rtos_init(long exinf)
{
  int no;

  for(no = 0 ; no < NUM_NXT_TIMER ; no++)
    rtos_1kHz_time_func[no] = 0;
}

void
rtos_1kHz_process(long exinf)
{
  int no;

  for(no = 0 ; no < NUM_NXT_TIMER ; no++){
    if(rtos_1kHz_time_func[no] != 0)
      rtos_1kHz_time_func[no]();
  }
}

int get_tim(SYSTIM *tim)
{
	*tim = cntcb_curval[SysTimerCnt];
	return 0;
}

int systick_wait_ms(long tim)
{
	tim = (tim + 39) / 40;
	while(tim > 0){
		WaitEvent( MainEvt );	/* 100ms�κ�Ȼ����Ԥ�	*/
		ClearEvent( MainEvt );
		tim--;
	}
	return 0;
}

