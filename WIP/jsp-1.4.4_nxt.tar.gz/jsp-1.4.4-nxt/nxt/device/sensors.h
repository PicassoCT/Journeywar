
/*
 * original:lejos-osek/src/nxtvm/platform/nxt/sensor.h rev.1.1.1.1
 * modified history.
 * 08/14/2009: Modifier Ryosuke Takeuchi
 *           : Modified for C++ language include file.
 */

#ifndef _SENSORS_H
#  define _SENSORS_H

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
  char type;
  char mode;
  short raw;
  short value;
  char boolean;
} sensor_t;


#  define N_SENSORS (4)

extern sensor_t sensors[N_SENSORS];
extern void init_sensors(void);
extern void poll_sensors(void);
extern void read_buttons(int, short *);
extern void check_for_data(char *valid, char **nextbyte);
extern void set_digi0(int);
extern void unset_digi0(int);
extern void set_digi1(int);
extern void unset_digi1(int);

#ifdef __cplusplus
}
#endif

#endif // _SENSORS_H
