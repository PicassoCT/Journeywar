
#include "rtos.h"

void (*rtos_1kHz_time_func[NUM_NXT_TIMER])(void);

void
rtos_init(long exinf)
{
  int no;

  for(no = 0 ; no < NUM_NXT_TIMER ; no++)
    rtos_1kHz_time_func[no] = 0;
}

void
rtos_1kHz_process(long exinf)
{
  int no;

  for(no = 0 ; no < NUM_NXT_TIMER ; no++){
    if(rtos_1kHz_time_func[no] != 0)
      rtos_1kHz_time_func[no]();
  }
}

