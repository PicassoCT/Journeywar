
/*
 * original:lejos-osek/src/nxtvm/platform/nxt/sensor.c rev.1.1.1.1
 * modified history.
 * 08/14/2009: Modifider Ryosuke Takeuchi
 *           : Modified Device Interface to ITRON-SIL interface and Changed
 *             AT91SAM7.h to SIL defined include file.
 *           : Modified intenal int function[] for a code size minimum.
 */

#include "rtos.h"
#include "sensors.h"
#include "nxt_avr.h"

extern int verbose;

sensor_t sensors[N_SENSORS] = {
  {0, 0, 0, 0, 0},
  {0, 0, 0, 0, 0},
  {0, 0, 0, 0, 0},
  {0, 0, 0, 0, 0}
};

void
init_sensors(void)
{
  int i;
  unsigned long base = TADR_PIO_BASE;
  unsigned long pio  = AT91S_PIO_PA5 | AT91S_PIO_PA6 | AT91S_PIO_PA7;

  for (i = 0; i < N_SENSORS; i++) {
    unset_digi0(i);
    unset_digi1(i);
    nxt_avr_set_input_power(i, 0);
  }
  /* Ensure RS485 is inactive. Otherwise it can interfere with
   * the operation of port 4.
   */
  sil_wrw_mem((VP)(base+TOFF_PIO_PER), sil_rew_mem((VP)(base+TOFF_PIO_PER)) | pio);
  sil_wrw_mem((VP)(base+TOFF_PIO_PUDR), sil_rew_mem((VP)(base+TOFF_PIO_PUDR)) | pio);
  sil_wrw_mem((VP)(base+TOFF_PIO_OER), sil_rew_mem((VP)(base+TOFF_PIO_OER)) | pio);
  sil_wrw_mem((VP)(base+TOFF_PIO_CODR), sil_rew_mem((VP)(base+TOFF_PIO_CODR)) | pio);
}

/**
 * Read sensor values
 */
void
poll_sensors(void)
{
  U8 i;
  sensor_t *pSensor = sensors;

  for (i = 0; i < N_SENSORS; i++, pSensor++) {
    pSensor->value = sensor_adc(i);
  }
}

void
read_buttons(int dummy, short *output)
{
  *output = (short) buttons_get();
}


void
check_for_data(char *valid, char **nextbyte)
{
  *valid = 0;
}

static const unsigned int functions_digi0[] = {
    AT91S_PIO_PA23, AT91S_PIO_PA28,
    AT91S_PIO_PA29, AT91S_PIO_PA30
};

void
set_digi0(int sensor)
{
  /* Enable output on the pin */
	unsigned long base = TADR_PIO_BASE;

  sil_wrw_mem((VP)(base+TOFF_PIO_PER), sil_rew_mem((VP)(base+TOFF_PIO_PER)) | functions_digi0[sensor]);
  sil_wrw_mem((VP)(base+TOFF_PIO_OER), sil_rew_mem((VP)(base+TOFF_PIO_OER)) | functions_digi0[sensor]);

  /* Set high */
  sil_wrw_mem((VP)(base+TOFF_PIO_SODR), sil_rew_mem((VP)(base+TOFF_PIO_SODR)) | functions_digi0[sensor]);

}

void
unset_digi0(int sensor)
{
  /* Enable output on the pin */
  unsigned long base = TADR_PIO_BASE;

  sil_wrw_mem((VP)(base+TOFF_PIO_PER), sil_rew_mem((VP)(base+TOFF_PIO_PER)) | functions_digi0[sensor]);
  sil_wrw_mem((VP)(base+TOFF_PIO_OER), sil_rew_mem((VP)(base+TOFF_PIO_OER)) | functions_digi0[sensor]);

  /* Set low */
  sil_wrw_mem((VP)(base+TOFF_PIO_CODR), sil_rew_mem((VP)(base+TOFF_PIO_CODR)) | functions_digi0[sensor]);
}

static const unsigned int functions_digi1[] = {
    AT91S_PIO_PA18, AT91S_PIO_PA19,
    AT91S_PIO_PA20, AT91S_PIO_PA2
};

void
set_digi1(int sensor)
{
  /* Enable output on the pin */
  unsigned long base = TADR_PIO_BASE;

  sil_wrw_mem((VP)(base+TOFF_PIO_PER), sil_rew_mem((VP)(base+TOFF_PIO_PER)) | functions_digi1[sensor]);
  sil_wrw_mem((VP)(base+TOFF_PIO_OER), sil_rew_mem((VP)(base+TOFF_PIO_OER)) | functions_digi1[sensor]);

  /* Set high */
  sil_wrw_mem((VP)(base+TOFF_PIO_SODR), sil_rew_mem((VP)(base+TOFF_PIO_SODR)) | functions_digi1[sensor]);
}

void
unset_digi1(int sensor)
{
  /* Enable output on the pin */
  unsigned long base = TADR_PIO_BASE;

  sil_wrw_mem((VP)(base+TOFF_PIO_PER), sil_rew_mem((VP)(base+TOFF_PIO_PER)) | functions_digi1[sensor]);
  sil_wrw_mem((VP)(base+TOFF_PIO_OER), sil_rew_mem((VP)(base+TOFF_PIO_OER)) | functions_digi1[sensor]);

  /* Set low */
  sil_wrw_mem((VP)(base+TOFF_PIO_CODR), sil_rew_mem((VP)(base+TOFF_PIO_CODR)) | functions_digi1[sensor]);
}
