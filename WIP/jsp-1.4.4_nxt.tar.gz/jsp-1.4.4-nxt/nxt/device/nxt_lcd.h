
/*
 * original:lejos-osek/src/nxtvm/platform/nxt/nxt_lcd.h rev.1.1.1.1
 * modified history.
 * 04/03/2010: Modifier Ryosuke Takeuchi
 *           : Modified for C++ language include file.
 *           : Modified nxt_lcd_init and nxt_lcd_power_up prottype define.
 */

#ifndef __NXT_LCD_H__
#  define __NXT_LCD_H__

#ifdef __cplusplus
extern "C" {
#endif

#  include "mytypes.h"

#  define NXT_LCD_WIDTH 100
#  define NXT_LCD_DEPTH 8

void nxt_lcd_init(const U8 *disp);
void nxt_lcd_power_up(const U8 *disp);
void nxt_lcd_power_down(void);
void nxt_lcd_data(const U8 *buffer);

#ifdef __cplusplus
}
#endif

#endif
