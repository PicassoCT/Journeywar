
/*
 * original:lejos-osek/src/nxtvm/platform/nxt/i2c.h rev.1.1.1.1
 * modified history.
 * 12/13/2009: Modifier Ryosuke Takeuchi
 *           : Modified for C++ language include file.
 *           : Modified i2c_init argument for ITRON ATT_INI statis API.
 */

#ifndef __I2C_H__
#define __I2C_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "mytypes.h"

#define I2C_N_PORTS 4

void i2c_disable(int port);
void i2c_enable(int port);

void i2c_init(long exinf);

int i2c_busy(int port);
int i2c_start_transaction(int port, 
                      U32 address, 
                      int internal_address, 
                      int n_internal_address_bytes, 
                      U8 *data, 
                      U32 nbytes,
                      int write);


void i2c_test(void);

#ifdef __cplusplus
}
#endif

#endif
