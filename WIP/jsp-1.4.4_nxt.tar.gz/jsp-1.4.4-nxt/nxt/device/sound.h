
/*
 * original:lejos-osek/src/nxtvm/platform/nxt/sound.h rev.1.1.1.1
 * modified history.
 * 04/16/2010: Modifier Ryosuke Takeuchi
 *           : Modified for C++ language include file.
 *           : Modified sound_init for ITRON ATT_INI static API.
 */

#ifndef SOUND_H_
#define SOUND_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "mytypes.h"

void sound_init(long exinf);
void sound_interrupt_enable();
void sound_interrupt_disable();
void sound_enable();
void sound_disable();
void sound_isr_C();

void sound_freq(U32 freq, U32 ms);

#ifdef __cplusplus
}
#endif

#endif /*SOUND_H_*/
