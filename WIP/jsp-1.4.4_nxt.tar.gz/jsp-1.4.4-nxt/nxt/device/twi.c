
/*
 * original:lejos-osek/src/nxtvm/platform/nxt/twi.c rev.1.1.1.1
 * modified history.
 * 11/04/2008: Modifier takashic
 *           : Modified TWM clock 380KHz to 400KHz.
 * 04/16/2010: Modifider Ryosuke Takeuchi
 *           : Modified Device Interface to ITRON-SIL interface and Changed
 *             AT91SAM7.h to SIL defined include file.
 *           : Deleted UNRE chack in twi_isr_C function.
 *           : Modified Interrupt disable in twi_init fuction for ITRON ATT_INI API.
 */

#include "rtos.h"
#include "mytypes.h"
#include "twi.h"
#include "byte_fifo.h"


// added by takashic 2008-11-14
// Calculate required clock divisor
#define   I2CClk                        400000L
#define   CLDIV                         (((CLOCK_FREQUENCY/I2CClk)/2)-3)

extern void twi_isr_entry(void);


static enum {
  TWI_UNINITIALISED = 0,
  TWI_IDLE,
  TWI_TX_BUSY,
  TWI_TX_DONE,
  TWI_RX_BUSY,
  TWI_RX_DONE,
  TWI_FAILED
} twi_state;

static volatile U32 twi_pending;
static volatile U8 *twi_ptr;

static volatile struct {
  U32 rx_done;
  U32 tx_done;
  U32 bytes_tx;
  U32 bytes_rx;
  U32 unre;
  U32 ovre;
  U32 nack;
} twi_stats;




int
twi_busy(void)
{
  return (twi_state == TWI_TX_BUSY || twi_state == TWI_RX_BUSY);
}

int
twi_ok(void)
{
  return (twi_state >= TWI_IDLE && twi_state <= TWI_RX_DONE);
}

void
twi_isr_C(void)
{
  unsigned long base =  TADR_TWI_BASE;
  volatile U32 status;

  status = sil_rew_mem((VP)(base+TOFF_TWI_SR));
  if((status & AT91S_TWI_RXRDY) && twi_state == TWI_RX_BUSY) {
    if (twi_pending) {
      twi_stats.bytes_rx++;
      *twi_ptr = sil_rew_mem((VP)(base+TOFF_TWI_RHR));
      twi_ptr++;
      twi_pending--;
      if (twi_pending == 1) {
        /* second last byte -- issue a stop on the next byte */
        sil_wrw_mem((VP)(base+TOFF_TWI_CR), AT91S_TWI_STOP);
      }
      if (!twi_pending) {
        twi_stats.rx_done++;
        twi_state = TWI_RX_DONE;
      }
    }
  }

  if((status & AT91S_TWI_TXRDY) && twi_state == TWI_TX_BUSY) {
    if (twi_pending) {
      /* Still Stuff to send */
      sil_wrw_mem((VP)(base+TOFF_TWI_CR), AT91S_TWI_MSEN | AT91S_TWI_START);
      if (twi_pending == 1) {
        sil_wrw_mem((VP)(base+TOFF_TWI_CR), AT91S_TWI_STOP);
      }
      sil_wrw_mem((VP)(base+TOFF_TWI_THR), *twi_ptr);
      twi_stats.bytes_tx++;

      twi_ptr++;
      twi_pending--;
    } else {
      /* everything has been sent */
      twi_state = TWI_TX_DONE;
      sil_wrw_mem((VP)(base+TOFF_TWI_IDR), ~0);	/* Disable all interrupts */
      twi_stats.tx_done++;
    }
  }

  if(status & AT91C_TWI_OVRE) {
    /* */
    twi_stats.ovre++;
    sil_wrw_mem((VP)(base+TOFF_TWI_CR), AT91S_TWI_STOP);
    sil_wrw_mem((VP)(base+TOFF_TWI_IDR), ~0);	/* Disable all interrupts */
    twi_state = TWI_FAILED;
  }

  if(status & AT91S_TWI_NACK) {
    /* */
    twi_stats.nack++;
    sil_wrw_mem((VP)(base+TOFF_TWI_IDR), ~0);	/* Disable all interrupts */
    twi_state = TWI_UNINITIALISED;
  }
}



void
twi_reset(void)
{
  volatile U32 clocks = 9;
  unsigned long pbase = TADR_PIO_BASE;
  unsigned long tbase = TADR_TWI_BASE;

  sil_wrw_mem((VP)(tbase+TOFF_TWI_IDR), ~0);	/* Disable all interrupts */
  sil_wrw_mem((VP)(TADR_PMC_BASE+TOFF_PMC_PCER), (1<<IRQ_PIOA_PID) |	/* Need PIO too */
    (1 << IRQ_TWI_PID));	/* TWI clock domain */

  /* Set up pin as an IO pin for clocking till clean */
  sil_wrw_mem((VP)(pbase+TOFF_PIO_MDER), AT91S_PIO_PA3 | AT91S_PIO_PA4);
  sil_wrw_mem((VP)(pbase+TOFF_PIO_PER), AT91S_PIO_PA3 | AT91S_PIO_PA4);
  sil_wrw_mem((VP)(pbase+TOFF_PIO_ODR), AT91S_PIO_PA3);
  sil_wrw_mem((VP)(pbase+TOFF_PIO_OER), AT91S_PIO_PA4);

  while(clocks > 0 && (sil_rew_mem((VP)(pbase+TOFF_PIO_PDSR)) & AT91S_PIO_PA3) == 0){
    sil_wrw_mem((VP)(pbase+TOFF_PIO_CODR), AT91S_PIO_PA4);
    systick_wait_ns(1500);
    sil_wrw_mem((VP)(pbase+TOFF_PIO_SODR), AT91S_PIO_PA4);
    systick_wait_ns(1500);
    clocks--;
  }
  sil_wrw_mem((VP)(pbase+TOFF_PIO_PDR), AT91S_PIO_PA3 | AT91S_PIO_PA4);
  sil_wrw_mem((VP)(pbase+TOFF_PIO_ASR), AT91S_PIO_PA3 | AT91S_PIO_PA4);

  sil_wrw_mem((VP)(tbase+TOFF_TWI_CR), 0x88);		/* Disable & reset */

// changed by takashic 2008-11-14
//  *AT91C_TWI_CWGR = 0x020f0f;	/* Set for 380kHz */
  sil_wrw_mem((VP)(tbase+TOFF_TWI_CWGR), ((CLDIV<<8)|CLDIV));	/* Set for 400kHz */
  sil_wrw_mem((VP)(tbase+TOFF_TWI_CR), 0x04);		/* Enable as master */
}

int
twi_init(void)
{
  sil_wrw_mem((VP)(TADR_TWI_BASE+TOFF_TWI_IDR), ~0);	/* Disable all interrupts */
  twi_reset();

  /* Init peripheral */
  twi_state = TWI_IDLE;
  return 1;
}



void
twi_start_read(U32 dev_addr, U32 int_addr_bytes, U32 int_addr, U8 *data,
	       U32 nBytes)
{
  volatile U32 mode =
    ((dev_addr & 0x7f) << 16) | ((int_addr_bytes & 3) << 8) | (1 << 12);
  volatile U32 dummy;
  unsigned long base = TADR_TWI_BASE;

  if (!twi_busy()) {
    twi_state = TWI_RX_BUSY;
    sil_wrw_mem((VP)(base+TOFF_TWI_IDR), ~0);	/* Disable all interrupts */
    twi_ptr = data;
    twi_pending = nBytes;
    dummy = sil_rew_mem((VP)(base+TOFF_TWI_SR));
    dummy = sil_rew_mem((VP)(base+TOFF_TWI_RHR));
    sil_wrw_mem((VP)(base+TOFF_TWI_MMR), mode);
    sil_wrw_mem((VP)(base+TOFF_TWI_CR), AT91S_TWI_START | AT91S_TWI_MSEN);
    sil_wrw_mem((VP)(base+TOFF_TWI_IER), 0x1C2);
  }
}

void
twi_start_write(U32 dev_addr, U32 int_addr_bytes, U32 int_addr,
		const U8 *data, U32 nBytes)
{
  volatile U32 mode = ((dev_addr & 0x7f) << 16) | ((int_addr_bytes & 3) << 8);
  unsigned long base = TADR_TWI_BASE;

  if (!twi_busy()) {
    twi_state = TWI_TX_BUSY;
    sil_wrw_mem((VP)(base+TOFF_TWI_IDR), ~0);	/* Disable all interrupts */
    twi_ptr = (volatile U8 *)data;
    twi_pending = nBytes;

    sil_wrw_mem((VP)(base+TOFF_TWI_MMR), mode);
    sil_wrw_mem((VP)(base+TOFF_TWI_CR), AT91S_TWI_START | AT91S_TWI_MSEN);
    sil_wrw_mem((VP)(base+TOFF_TWI_IER), 0x1C4);
  }
}
