
/*
 * original:lejos-osek/src/nxtvm/platform/nxt/nxt_avr.h rev.1.1.1.1
 * modified history.
 * 12/13/2009: Modifier Ryosuke Takeuchi
 *           : Modified for C++ language include file.
 *           : Modified nxt_avr_init argument for ITRON ATT_INI statis API.
 *           : Deleted nxt_avr_1kHz_update protype define.
 */

#ifndef __NXT_AVR_H__
#  define __NXT_AVR_H__

#ifdef __cplusplus
extern "C" {
#endif

#  include "mytypes.h"


/* Main user interface */
void nxt_avr_init(long exinf);

void nxt_avr_set_motor(U32 n, int power_percent, int brake);

void nxt_avr_power_down(void);

void nxt_avr_test_loop(void);

void nxt_avr_update(void);

U32 buttons_get(void);

U32 battery_voltage(void);

U32 sensor_adc(U32 n);

void nxt_avr_set_input_power(U32 n, U32 power_type);

#ifdef __cplusplus
}
#endif

#endif
