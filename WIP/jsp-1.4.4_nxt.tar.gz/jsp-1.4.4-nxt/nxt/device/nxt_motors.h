
/*
 * original:lejos-osek/src/nxtvm/platform/nxt/nxt_motor.h rev.1.1.1.1
 * modified history.
 * 12/13/2009: Modifier Ryosuke Takeuchi
 *           : Modified for C++ language include file.
 *           : Modified nxt_motor_init argument for ITRON ATT_INI static API.
 *           : Deleted nxt_motor_1kHz_process prottype define.
 */

#ifndef __NXT_MOTORS_H__
#  define __NXT_MOTORS_H__

#ifdef __cplusplus
extern "C" {
#endif

#  include "mytypes.h"

#  define NXT_N_MOTORS 3

int nxt_motor_get_count(U32 n);
void nxt_motor_set_count(U32 n, int count);

void nxt_motor_set_speed(U32 n, int speed_percent, int brake);

void nxt_motor_command(U32 n, int cmd, int target_count, int speed_percent);

void nxt_motor_init(long exinf);


#ifdef __cplusplus
}
#endif

#endif
