
/*
 * original:lejos-osek/src/nxtvm/platform/nxt/udp.c rev.1.1.1.1
 * modified history.
 * 04/11/2010: Modifider Ryosuke Takeuchi
 *           : Modified Device Interface to ITRON-SIL interface and Changed
 *             AT91SAM7.h to SIL defined include file.
 *           : Modified interrupt disable in upd_init function.
 */

#include "rtos.h"
#include "mytypes.h"
#include "udp.h"
#include "display.h"
#include <string.h>


#define EP_OUT	1
#define EP_IN	2

#  define AT91C_CKGR_USBDIV     ((unsigned int) 0x3 << 28)	// (CKGR) Divider for USB Clocks
#  define 	AT91C_CKGR_USBDIV_0                    ((unsigned int) 0x0 << 28)	// (CKGR) Divider output is PLL clock output
#  define 	AT91C_CKGR_USBDIV_1                    ((unsigned int) 0x1 << 28)	// (CKGR) Divider output is PLL clock output divided by 2
#  define 	AT91C_CKGR_USBDIV_2                    ((unsigned int) 0x2 << 28)	// (CKGR) Divider output is PLL clock output divided by 4

// -------- PMC_SCER : (PMC Offset: 0x0) System Clock Enable Register -------- 
#  define AT91C_PMC_UDP         ((unsigned int) 0x1 <<  7)	// (PMC) USB Device Port Clock

static unsigned currentConfig;
static unsigned currentConnection;
static unsigned currentRxBank;

void
udp_isr_C(void)
{

}


int
udp_init(void)
{
  /* Make sure the USB PLL and clock are set up */
  sil_wrw_mem((VP)(TADR_PMC_BASE+TOFF_CKGR_PLLR), AT91C_CKGR_USBDIV_1);
  sil_wrw_mem((VP)(TADR_PMC_BASE+TOFF_PMC_SCER), AT91C_PMC_UDP);
  sil_wrw_mem((VP)(TADR_PMC_BASE+TOFF_PMC_PCER), (1 << IRQ_UDP_PID));

  /* Enable the UDP pull up by outputting a zero on PA.16 */
  sil_wrw_mem((VP)(TADR_PIO_BASE+TOFF_PIO_PER), (1 << 16));
  sil_wrw_mem((VP)(TADR_PIO_BASE+TOFF_PIO_OER), (1 << 16));
  sil_wrw_mem((VP)(TADR_PIO_BASE+TOFF_PIO_CODR), (1 << 16));

  /* Set up default state */

  currentConfig = 0;
  currentConnection = 0;
  currentRxBank = 0;

  return 1;
}

void
udp_close(U32 u)
{
  /* Nothing */
}
