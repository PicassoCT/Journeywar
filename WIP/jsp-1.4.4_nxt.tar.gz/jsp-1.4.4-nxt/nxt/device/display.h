
/*
 * original:lejos-osek/src/nxtvm/platform/nxt/display.h rev.1.1.1.1
 * modified history.
 * 04/03/2010: Modifier Ryosuke Takeuchi
 *           : Modified for C++ language include file.
 *           : Added display_refresh protype define.
 *           : Modified display_init protype define.
 */

#ifndef __DISPLAY_H__
#  define __DISPLAY_H__

#ifdef __cplusplus
extern "C" {
#endif

#  include "mytypes.h"

#define display_refresh nxt_spi_refresh

void display_init(long exinf);

void display_update(void);

void display_clear(U32 updateToo);

void display_goto_xy(int x, int y);

void display_char(int c);

void display_string(const char *str);

void display_int(int val, U32 places);
void display_hex(U32 val, U32 places);

void display_unsigned(U32 val, U32 places);

void display_bitmap_copy(const U8 *data, U32 width, U32 depth, U32 x, U32 y);

void display_test(void);

U8 *display_get_buffer(void);

#ifdef __cplusplus
}
#endif

#endif
