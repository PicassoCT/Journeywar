
/*
 * original:lejos-osek/src/nxtvm/platform/nxt/sound.c rev.1.1.1.1
 * modified history.
 * 04/16/2010: Modifider Ryosuke Takeuchi
 *           : Modified Device Interface to ITRON-SIL interface and Changed
 *             AT91SAM7.h to SIL defined include file.
 *           : Modified sound_init for ITRON interrupt system.
 */

#include "mytypes.h"
#include "rtos.h"
#include "sound.h"

extern void sound_isr_entry(void);

const U32 tone_pattern[16] =
  {
    0xF0F0F0F0,0xF0F0F0F0,
    0xFCFCFCFC,0xFCFCFDFD,
    0xFFFFFFFF,0xFFFFFFFF,
    0xFDFDFCFC,0xFCFCFCFC,
    0xF0F0F0F0,0xF0F0F0F0,
    0xC0C0C0C0,0xC0C08080,
    0x00000000,0x00000000,
    0x8080C0C0,0xC0C0C0C0
  };

U32 tone_cycles;

void sound_init(long exinf)
{
  sound_interrupt_disable();
  sound_disable();

  sil_wrw_mem((VP)(TADR_PMC_BASE+TOFF_PMC_PCER), 1<<IRQ_SSC_PID);

  //*AT91C_PIOA_ODR = AT91C_PA17_TD;
  //*AT91C_PIOA_OWDR = AT91C_PA17_TD;
  //*AT91C_PIOA_MDDR = AT91C_PA17_TD;
  //*AT91C_PIOA_PPUDR = AT91C_PA17_TD;
  //*AT91C_PIOA_IFDR = AT91C_PA17_TD;
  //*AT91C_PIOA_CODR = AT91C_PA17_TD;

  sil_wrw_mem((VP)(TADR_SSC_BASE+TOFF_SSC_CR), SSC_SWRST);
  sil_wrw_mem((VP)(TADR_SSC_BASE+TOFF_SSC_TCMR), SSC_CKS_DIV+SSC_CKO_CONTINOUS+SSC_START_CONTINOUS);
  sil_wrw_mem((VP)(TADR_SSC_BASE+TOFF_SSC_TFMR), 31 + (7 << 8) + SSC_MSBF); // 8 32-bit words
  sil_wrw_mem((VP)(TADR_SSC_BASE+TOFF_SSC_CR), SSC_TXEN);

  sil_wrw_mem((VP)(TADR_AIC_BASE+TOFF_AIC_ICCR), 1<<IRQ_SSC_PID);
}

void sound_freq(U32 freq, U32 ms)
{
  sil_wrw_mem((VP)(TADR_SSC_BASE+TOFF_SSC_CMR), ((96109714 / 1024) / freq) + 1);
  sil_wrw_mem((VP)(TADR_SSC_BASE+TOFF_SSC_PTCR), PDC_TXTEN);
  tone_cycles = (freq * ms) / 2000 - 1;
  sound_interrupt_enable();
}

void sound_interrupt_enable()
{
  sil_wrw_mem((VP)(TADR_SSC_BASE+TOFF_SSC_IER), SSC_ENDTX);
}

void sound_interrupt_disable()
{
  sil_wrw_mem((VP)(TADR_SSC_BASE+TOFF_SSC_IDR), SSC_ENDTX);
}

void sound_enable()
{
  sil_wrw_mem((VP)(TADR_PIO_BASE+TOFF_PIO_PDR), AT91S_PIO_PA17);
}

void sound_disable()
{
  sil_wrw_mem((VP)(TADR_PIO_BASE+TOFF_PIO_PER), AT91S_PIO_PA17);
}

void sound_isr_C()
{
  if (tone_cycles--)
  {
    sil_wrw_mem((VP)(TADR_SSC_BASE+TOFF_SSC_TNPR), (unsigned int) tone_pattern);
    sil_wrw_mem((VP)(TADR_SSC_BASE+TOFF_SSC_TNCR), 16);
    sound_enable();
  }
  else
  {
  	sound_disable();
  	sound_interrupt_disable();
  }
}
